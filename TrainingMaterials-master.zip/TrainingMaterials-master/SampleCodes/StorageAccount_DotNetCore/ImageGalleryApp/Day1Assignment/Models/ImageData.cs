﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Models
{
    public class ImageData
    {
        public string Caption { get; set; }
       
        public string FileName { get; set; }
    }
}
