﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;

namespace Day1Assignment.ServiceHelpers
{

    /// <summary>
    /// Add the following NuGet package
    /// Install-Package Microsoft.WindowsAzure.ConfigurationManager
    /// Install-Package WindowsAzure.Storage
    /// </summary>
    public class StorageHelper
    {
        private static string _connectionString;
        private static CloudStorageAccount storageAccount;

        public static string ConnectionString
        {
            get { return _connectionString; }
            set
            {
                if (_connectionString != value)
                {
                    _connectionString = value;
                    ConfigureStorage();
                }
            }
        }

        private static void ConfigureStorage()
        {
            if(!CloudStorageAccount.TryParse(_connectionString, out storageAccount))
            {
                throw new Exception("Could not initialize storage account object");
            }
        }

        public static async Task<string> UploadImageAsync(string imagePath, string containerName)
        {
            var fileName = Path.GetFileName(imagePath);

            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(containerName);
            await blobContainer.CreateIfNotExistsAsync();
            BlobContainerPermissions permissions = new BlobContainerPermissions
            {
                PublicAccess = BlobContainerPublicAccessType.Blob
            };            
            await blobContainer.SetPermissionsAsync(permissions);
            CloudBlockBlob blob= blobContainer.GetBlockBlobReference(fileName);
            blob.Properties.ContentType = GetFileType(imagePath);               
            await blob.UploadFromFileAsync(imagePath);
            return blob.Uri.AbsoluteUri;
        }

        public static async Task<IEnumerable<string>> GetFilesAsync(string containerName)
        {
            var blobList = new List<string>();
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            var exists = await container.ExistsAsync();
            if (!exists)
            {
                throw new Exception("Specified container does not exists");
            }
            BlobContinuationToken continuationToken=null;
            var result = await container.ListBlobsSegmentedAsync(continuationToken);
            do
            {
                blobList.AddRange(result.Results.Select(blob =>blob.Uri.AbsoluteUri));
                continuationToken = result.ContinuationToken;
            } while (continuationToken != null);

            return blobList;
        }

        public static async Task<string> GetContainerSasUri(string containerName,  DateTimeOffset expiryTime)
        {
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            await container.CreateIfNotExistsAsync();
            SharedAccessBlobPolicy SasPolicy = new SharedAccessBlobPolicy()
            {
                SharedAccessExpiryTime = expiryTime,                
                Permissions = SharedAccessBlobPermissions.List | SharedAccessBlobPermissions.Read | SharedAccessBlobPermissions.Create
            };
            return container.Uri + container.GetSharedAccessSignature(SasPolicy);
        }

        public static async Task<string> GetBlobSasUri(string containerName, string blobName,  DateTimeOffset expiryTime)
        {
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            var exists = await container.ExistsAsync();
            if (!exists)
            {
                throw new Exception("Specified container does not exists");
            }
            CloudBlockBlob blob = container.GetBlockBlobReference(blobName);
            var blobExists = await blob.ExistsAsync();
            if (!blobExists)
            {
                throw new Exception("Specified blob does not exists in container");
            }
            SharedAccessBlobPolicy SasPolicy = new SharedAccessBlobPolicy()
            {
                SharedAccessExpiryTime = expiryTime,                
                Permissions = SharedAccessBlobPermissions.Write | SharedAccessBlobPermissions.Read
            };
            return blob.Uri + blob.GetSharedAccessSignature(SasPolicy);
        }

        public static async void CreateContainerStoredAccessPolicyAsync(string containerName,string policyName, DateTimeOffset expiryTime)
        {
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            await container.CreateIfNotExistsAsync();
            BlobContainerPermissions permissions = await container.GetPermissionsAsync();
            SharedAccessBlobPolicy sharedPolicy = new SharedAccessBlobPolicy()
            {
                SharedAccessExpiryTime = expiryTime,
                Permissions = SharedAccessBlobPermissions.Write | SharedAccessBlobPermissions.List | SharedAccessBlobPermissions.Read
            };
            permissions.SharedAccessPolicies.Add(policyName, sharedPolicy);
            await container.SetPermissionsAsync(permissions);

        }

        public static async Task<string> GetContainerSasUriFromStoredPolicy(string containerName, string policyName)
        {
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer container = blobClient.GetContainerReference(containerName);
            var exists = await container.ExistsAsync();
            if (!exists)
            {
                throw new Exception("Specified container does not exists");
            }
            var permissions=await container.GetPermissionsAsync();
            var policy=permissions.SharedAccessPolicies.SingleOrDefault(s => s.Key == policyName);
            if(policy.Key == null)
            {
                throw new Exception("No Stored Access Policy exists with the given policy name");
            }
            return container.Uri + container.GetSharedAccessSignature(null, policyName);
        }

        public static async Task<string> UploadImageWithContainerSasAsync(string imagePath, string containerSas)
        {
            var filename = Path.GetFileName(imagePath);
            CloudBlobContainer container = new CloudBlobContainer(new Uri(containerSas));
            var blob=container.GetBlockBlobReference(filename);
            blob.Properties.ContentType = GetFileType(imagePath);
            await blob.UploadFromFileAsync(imagePath);
            return blob.Uri.AbsoluteUri;

        }

        private static string GetFileType(string fileName)
        {
            var provider = new FileExtensionContentTypeProvider();
            string contentType;
            if (!provider.TryGetContentType(fileName, out contentType))
            {
                contentType = "application/octet-stream";
            }
            return contentType;
        }
    }
}
