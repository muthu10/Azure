﻿using Day1Assignment.Models;
using Day1Assignment.ServiceHelpers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Services
{
    public class GalleryService : IGalleryService
    {
        private Dictionary<string, string> imageDict = new Dictionary<string, string>();

        public async Task<Dictionary<string, string>> GetImagesAsync()
        {
            var files= await StorageHelper.GetFilesAsync("images");
            foreach(var file in files)
            {
                imageDict.TryAdd(Path.GetFileName(file), file);
            }
            return imageDict;
        }

        public async Task<string> AddImageAsync(ImageData imageData, string imagePath)
        {
            //var blobUrl = await StorageHelper.UploadImageAsync(imagePath, "images");
            //return blobUrl;

            var containerSasUri= await StorageHelper.GetContainerSasUri("images", DateTimeOffset.UtcNow.AddDays(2));
            var blobUrl= await StorageHelper.UploadImageWithContainerSasAsync(imagePath, containerSasUri);
            return blobUrl;
        }
    }
}
