﻿using Day1Assignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Day1Assignment.Services
{
    public interface IGalleryService
    {
        Task<Dictionary<string, string>> GetImagesAsync();
        Task<string> AddImageAsync(ImageData imageData, string imagePath);
    }
}
